/*     
       routine reads r theta phi TIME d_r(vr) d_t(vr) d_p(vr) ...
                                      d_r(vt) d_t(vt) d_p(vt) ...
		                      d_r(vp) d_t(vp) d_p(vp) 

       and converts the velocity gradient matrix to cartesian
       
       output is

       x y z TIME d_x vx d_y vx d_z vx ... 
                  d_x vy d_y vy d_z vy ...
                  d_x vz d_y vz d_z vz
       
  
      $Id: polvgm2cartvgm.c,v 1.4 2004/04/17 19:42:52 becker Exp $
*/
  
#include "fstrack.h"

int main(int argc, char **argv)
{
  COMP_PRECISION pvgm[3][3],cvgm[3][3],time,px[3],cx[3];
  int n=0;
  /* read in VGM in spherical coordinates */
  while(fscanf(stdin,"%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
	       (px+R),(px+THETA),(px+PHI),&time,
	       &pvgm[R][R],    &pvgm[R][THETA],    &pvgm[R][PHI],
	       &pvgm[THETA][R],&pvgm[THETA][THETA],&pvgm[THETA][PHI],
	       &pvgm[PHI][R],  &pvgm[PHI][THETA],  &pvgm[PHI][PHI])==13){
    rtp2xyz(px,cx);		/* convert location from polar to cartesian*/
    /* convert matrix from polar to cartesian system */
    polar_to_cart_mat_at_r3x3(pvgm,cvgm,px);
    fprintf(stdout,"%16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e %16.8e\n",
	    cx[X],cx[Y],cx[Z],time,
	    cvgm[X][X],cvgm[X][Y],cvgm[X][Z],
	    cvgm[Y][X],cvgm[Y][Y],cvgm[Y][Z],
	    cvgm[Z][X],cvgm[Z][Y],cvgm[Z][Z]);
    if(fabs(pvgm[X][X]+pvgm[Y][Y]+pvgm[Z][Z]) > 1e-7){ /* check trace, should be zero */
      fprintf(stderr,"trace: %11g %11g\n",
	      pvgm[X][X]+pvgm[Y][Y]+pvgm[Z][Z],
	      cvgm[X][X]+cvgm[Y][Y]+cvgm[Z][Z]);
    }
    n++;
  }
  if(n)
    fprintf(stderr,"%s: converted %i entries\n",argv[0],n);
  else{
    fprintf(stderr,"%s: error, n is zero\n",argv[0]);
    exit(-1);
  }
  return 0;
}
