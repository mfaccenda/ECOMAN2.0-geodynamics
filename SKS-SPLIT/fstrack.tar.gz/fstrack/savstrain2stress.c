#include "fstrack.h"
/* 


read in SAV tensor and strain from GPS to produce stress


*/

int main(int arc, char **argv)
{
  FILE *in;

  














}
