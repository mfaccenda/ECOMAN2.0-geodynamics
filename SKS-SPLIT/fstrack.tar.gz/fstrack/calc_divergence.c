#include "fstrack.h"

/*

  debugging routine that calculates the divergence
  using central differences given a discrete flow
  field as read in by read_vel_grids
  
  $Id: calc_divergence.c,v 1.5 2004/04/19 18:38:36 becker Exp twb $

*/


void calc_divergence(struct mod *model)
{
  COMP_PRECISION ddx[3],// d_r v_r, d_phi v_phi, d_theta v_theta
    *cottheta,*invsintheta,theta,invr,dx[3],div;
  int i,j,k,index,id[3][2],nm[3];
  // 1/sin(theta) and 1/tan(theta) factors
  cottheta=(COMP_PRECISION *)malloc(sizeof(COMP_PRECISION)*MDP->n[THETA]);
  invsintheta=(COMP_PRECISION *)malloc(sizeof(COMP_PRECISION)*MDP->n[THETA]);
  if(!cottheta || !invsintheta)MEMERROR("calc_divergence");
  for(theta=MDP->dtheta*0.5,i=0;i<MDP->n[THETA];i++,theta+=MDP->dtheta){
    invsintheta[i] = 1.0/sin(theta);
    cottheta[i]=1.0/tan(theta);
  }
  for(i=0;i<3;i++)// last entries
    nm[i]=MDP->n[i]-1;
  dx[PHI]= 2.0*MDP->dphi;
  //for(i=0;i<MDP->n[R];i++){
  for(i=MDP->n[R]/2;i<=MDP->n[R]/2;i++){
    invr = 1.0/MDP->rlevels[i];
    if(i == 0){// forward difference in r
      id[R][1]=1;
      id[R][0]=0;
    }else if(i == nm[R]){// backward in r
      id[R][1]= i;
      id[R][0]= i - 1;
    }else{// central
      id[R][1]=i + 1;
      id[R][0]=i - 1;
    }
    dx[R] = MDP->rlevels[id[R][1]] - MDP->rlevels[id[R][0]];
    for(j=0;j<MDP->n[THETA];j++){
      if(j == 0){// forward difference in theta
	id[THETA][1]=1;
	id[THETA][0]=0;
	dx[THETA] = MDP->dtheta;
      }else if(j == nm[THETA]){// backward in theta
	id[THETA][1]=j;
	id[THETA][0]=j-1;
	dx[THETA] = MDP->dtheta;
      }else{// central 
	id[THETA][1]=j+1;
	id[THETA][0]=j-1;
	dx[THETA] = 2.0 * MDP->dtheta;
      }
      for(k=0;k<MDP->n[PHI];k++){
	if(k==0){
	  id[PHI][1] = 1;
	  id[PHI][0] = nm[PHI];
	}else if(k == nm[PHI]){
	  id[PHI][1] = 0;
	  id[PHI][0] = nm[PHI]-1;
	}else{
	  id[PHI][1] = k + 1;
	  id[PHI][0] = k - 1;
	}
	// d_r v_r
	ddx[R] = ((COMP_PRECISION)MDP->vr[VOFF(id[R][1],j,k)] - (COMP_PRECISION)MDP->vr[VOFF(id[R][0],j,k)])/
	  dx[R];
	// d_t v_theta
	ddx[THETA] = ((COMP_PRECISION)MDP->vt[VOFF(i,id[THETA][1],k)] - (COMP_PRECISION)MDP->vt[VOFF(i,id[THETA][0],k)])/
	  dx[THETA];
	// d_p v_phi
	ddx[PHI] = ((COMP_PRECISION)MDP->vp[VOFF(i,j,id[PHI][1])] - (COMP_PRECISION)MDP->vp[VOFF(i,j,id[PHI][0])])/
	  dx[PHI];
	
	div  = ddx[R];
	index = VOFF(i,j,k);
	div += invr*(2.0*(COMP_PRECISION)MDP->vr[index] + ddx[THETA] + 
		     (COMP_PRECISION)MDP->vt[index] * cottheta[j] +
		     ddx[PHI] * invsintheta[j] );
	fprintf(stderr,"%3i %3i %3i div: %11g\n",i,j,k,div);
      }
    }
  }

  free(cottheta);free(invsintheta);
}

