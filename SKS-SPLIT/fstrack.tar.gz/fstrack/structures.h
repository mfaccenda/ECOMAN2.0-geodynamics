/*


 STRUCTURES for fstrack program 

 $Id: structures.h,v 1.18 2006/06/15 20:23:06 becker Exp becker $

*/
#include "precision.h"



/* 
   
surface wave sensitivity kernel

*/
struct swss_layer{
  COMP_PRECISION r,RA,RF,RL;	/* depth and parameters for SW sens layer, Rayleigh parmaters */
  COMP_PRECISION LL, LN;	/* Love */
};
struct swss{
  COMP_PRECISION p;		/* period */
  int n;			/* number of depth layers */
  struct swss_layer *l;		/* one layer */

};
/*

  (deformation) state (of-a-tracer) structure
  
  holds the strain matrix s, which is (normally) the squared
  left-stretch tensor, L, L^2,
  the position x[0..2] of the tracer at time t
  and the deformation matrix F, which is in x[3....8]

  IF YOU ADD VARIABLES HERE, MAKE SURE TO ADJUST HANDLE_STATE ROUTINES SUCH 
  AS COPY_STATE

*/
struct stt{
  COMP_PRECISION left_stretch[9];/* 
				    L^2, the squared left stretch strain matrix or 
				    Lyapunov exponents
				 */
  COMP_PRECISION x[12];/* 
			  position vector plus deformation matrix, f[i]=x[i+3]
			  x: 0 1 2 3 4 5 6 7 8 9 10 11
			  r: 0 1 2                      r vector
			  f:       0 1 2 3 4 5 6  7  8  deformation
			           rr      tt        pp
		       */

  COMP_PRECISION t; // time
  //
  // for ISA calculation: grain orientation lag parameter
  COMP_PRECISION pipar;
  //
  // ISA vector
  COMP_PRECISION isa[3];
  // does ISA exist?
  my_boolean isa_exists;
  /* 
     texture related
  */
  COMP_PRECISION Sav[36];	/* average stiffness tensor from
				   texture computation, stored in C
				   style (doesn't matter, since
				   symmetric)
				*/
  int npole;			/* tracer pole density size counter */
  COMP_PRECISION *pdens;		/* pole figure values  */
#define MAX_OL_AXES_ENTRIES 9
  COMP_PRECISION olivine_axes_stats[MAX_OL_AXES_ENTRIES]; /* olivine axes stats,
							     unweighted and weighted */
};

/*

  TRACER structure, holds nstate number of states

*/
#define NR_T_ATTR 1
struct trc{
  struct stt *state; // states, ie. strain and position at certain time
  unsigned short int nstate;// number of different states
  my_boolean discarded; // some tracers can be discarded for various reasons
  COMP_PRECISION attr[NR_T_ATTR];// scalar tracer attribute(s)
};


/*

  depth weight structure, used by average_tracers

*/
struct dw{
  int n; // nr of weights
  COMP_PRECISION *z,*w;/* depth where weight is specified and weight at 
			  that depth */
};
/*

strain structure, used by average_tracers

*/
// definitions for strain averaging arrays
#define STR_N_ESI 5 // nr of fields
#define STR_ESI_S_H 0 // the horizontal component of e1/e2 times the e1 vector
#define STR_ESI_AZI 1  // the azimuth of that componennt (degrees)
#define STR_ESI_LRR 2  // L_rr
#define STR_ESI_AX 3   // the x part of the horizontal projection 
#define STR_ESI_AY 4   // the y part 
struct str{
  COMP_PRECISION x[3],l[9],age,ws,wss;/* position: x 
					 L and age at
					 each depth, sum of weights,
					 and strain weighted sum of weights */
  COMP_PRECISION es[STR_N_ESI];/* log(e1/e2)_h azi[deg], 
				  lrr, azi_x, azi_y at each depth 
			   */
  COMP_PRECISION dazi,oldazi; // accumulated absolute rotation and old azimuth
  COMP_PRECISION pipar;/* grain orientation lag GOL factor */
};

/* 

structure to hold all variables that belong to derivative
calculations for Runge Kutta


*/
struct der_par{
  /* 
     general parameters for Runge Kutta integration 
     (those were global in Numerical recipes)

     kmax is the number of intermediate results stored
     dxsav is the time interval for storage
  */
  int kmax,kount,nok,nbad;
  COMP_PRECISION *xp,*yp,dxsav,tbailout,hmax;
  EXT_FTRN_PREC rkeps;		/* precision of stepper */
  int error_mode;		/* for determine_error_scale */
  my_boolean strain_rate_control; /* this uses -eps_strain/strain_rate as the max
				     time step for Runge Kutta */
  COMP_PRECISION eps_strain;


  /* 
     
  additional parameters for problem

  */
  /* 

     velocity field related 

  */
  VPREC *vr, *vt, *vp; /* r, theta, phi velocities */
  int n[5];/* n[0]: n_r n[1]: n_theta n[2]: n_phi 
	      n[3]: n_theta * n_phi   n[4]: n_theta * n_phi * n_r
	   */
  COMP_PRECISION dtheta,dphi;	/* spacing */
  COMP_PRECISION *rlevels;	/* radial levels */
  COMP_PRECISION velscale;// velocity scale
  /* timedependence of v */
  my_boolean history;/* if true, read in velocities at different
		     times as specified in times.dat */
  COMP_PRECISION *vtimes;/* [nvtimes*3]
			    time intervals (t_left t_mid t_right) 
			    at which velocities are given
			 */
  int nvtimes;/* nr of time intervals at which velocities are given, ie. 
		 vtimes is vtimes(nvtimes*3) */
  /* 
     operational quantities 
  */
  my_boolean remove_strain;	/* remove the strain, leave only the rotation? 
				   (this is typically FALSE)
				*/
  my_boolean strain_fraction_from_gamma; /* compute the strain-rate
					    fraction of the velocity
					    gradient tensor using
					    er.i.grd data with ratios
					    between dislocation and
					    diffusion creep */
#ifdef FSTRACK_USE_GGRD
  struct ggrd_gt ggrd_alpha[1];
#endif  
  /* 
     derived quantities 
  */
  COMP_PRECISION *vhdivmax;	/* max divergence at a given time */
  /* 
     spherical velocities
  */
  COMP_PRECISION v_loc[3];
  /* 
     velocity gradient matrix
  */
  COMP_PRECISION vgm[9];
  /* 

  calculation of Lyapunov exponents
  
  */
  my_boolean calc_lyapunov ;
  /* 
     renormalization limit and bailout crit and time renorm is the
     critical element of F size when renomalization takes place
  */
  COMP_PRECISION renorm,rlbailout,tmax;	
  COMP_PRECISION rlyap[3];	/* exponents */
  /* 

  DREX related
  
  */
  COMP_PRECISION drex_epsfac;	/* factor for RK errors, set to unity 
				   for equal error estimates, larger than 
				   unity for less precision, or smaller than zero
				   for -drex_epsfac/strain_rate for the max time step
				*/
  int drex_size3;		/* 
				   number of grains per direction 
				*/
  COMP_PRECISION drex_chi,drex_Mob,drex_Xol,drex_lambda; /* other parameters */
  int drex_type;	/*  
			    slip system type, see drex.h
			*/
  COMP_PRECISION drex_rss_tau[4]; /* resolved shear stresses on slip systems for free format */
  my_boolean drex_save_pole; 		/* save ODFs? */
  my_boolean drex_compute_avg_axes;	/* compute the average ODF axes? */
  int drex_module;	/* T,p dependent modules modes */
  COMP_PRECISION drex_module_p, /* pressure and temperature */
    drex_module_t;
  my_boolean drex_start_grains_oriented; /* start with a defined, rather than random distribution */
  int drex_np[2],drex_npole;	/* dimensions of ODF array */
  COMP_PRECISION drex_sstp;	/* transition pressure */
  struct drex_para *drex;

  /* 
     mode for texture development:
     0: off
     1: Kaminski and Ribe
  */
  int texture_mode;
  /* averaging: 0 hill 0.5 VHR 1: reuss*/  
  COMP_PRECISION vhr_favg;
  /* 

  grain orientation rotation (before gridding ODF functions)
  if TRUE, will rotate grains from globsal Cartesian system to 
  local E-N-U system. If false, will leave as is

  */
  my_boolean rotate_grain_coord_sys;
  /* 
     print the direction cosines for olivine [100] to file for 
     each timestep?
  */
  my_boolean print_o1xyz;
  int lpo_tracer_count;		/* count the number of times, LPOs are computed  */
  my_boolean constant_vgm_for_debugging;	/* this allows setting up 
						   a constant velocity gradient a
						   matrix and should be FALSE by 
						   default
						*/
  COMP_PRECISION cvfd_stw[3];	/* 
				   those are the S, T, and W values
				   from McKenzie & Jackson (1982) which will be 
				   used to assign a constant velocity gradient matrix 
				*/
};

/*
  
 MODEL STRUCTURE

 holds pointers to the velocities at certain depth levels, the tracers
 and other control variables

*/
#define MAX_NR_TINIT_LEVELS 30
struct mod{
  //
  // tracer related
  //
  int tinitmode;// tracer init mode
  unsigned int ntracer; // number of tracers
  struct trc *tracer;// tracer structures
  char tlatfilename[STRLEN];// filename with lateral tracer distribution
  // depth levels
  int ntlevels;// nr of levels
  COMP_PRECISION *tlevel,init_tracer_depth;// depth levels, single layer 
  char tdepthfilename[STRLEN];// depth level filename
  unsigned int *ntd;// nr of tracers at this depth
  my_boolean tdepth_from_file;
  int ntout;// nr of tracers that are output 
  //
  // advect mode
  int amode;
 
  // nsteps of advection for tracer history output
  int nsteps;
  //
  // bailout values for advect
  //
  COMP_PRECISION sdepth;// target depth 
  COMP_PRECISION maxstrain;// 
  COMP_PRECISION tf;// final time, forward or backward
  COMP_PRECISION itime;// intial time for forward advection, usually zero
  COMP_PRECISION bstime;// time for bailout when tracing strains backward

  my_boolean use_initial_strain; /* this is normally off, 
				    start with unity matrix */
  COMP_PRECISION initial_strain[9]; /* possible initial strain in spherical 
				       system */
  /*

  infinite strain axis related: 
  critical pi parameter, if larger, ISA doesn't exist
  */
  COMP_PRECISION pi_crit;
  /* 

  load the surface wave sensitivity functions?
     
  */
  my_boolean use_sw_sens;
  my_boolean sw_sens_init;
  struct swss *swsens;
  char sw_sens_file[STRLEN];	/* starting filename */
  // IO related
  my_boolean read_gmt;
  my_boolean verbose;
  char ostring[STRLEN];		/* suffix for output files */
  my_boolean sav_out;		/* output of stiffness tensor for texture */
  /* 
     derivative parameters  
  */
  struct der_par *dp;
};
/* shortcut to access the derivative related parameters */
#define MDP model->dp
/* shortcut to access the DREX parameters */
#define DREX model->dp->drex

